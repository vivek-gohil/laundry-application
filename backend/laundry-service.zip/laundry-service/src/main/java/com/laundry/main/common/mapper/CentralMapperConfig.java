package com.laundry.main.common.mapper;

import org.mapstruct.MapperConfig;

@MapperConfig(componentModel = "spring")
public interface CentralMapperConfig {
}
