package com.laundry.main.order.dto;

import java.time.LocalDate;
import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class OrderRequest {

    @NotNull(message = "Customer id is required")
    private Long customerId;


    private LocalDate pickupDate;

    private LocalDate deliveryDate;
    private String status;

    @NotNull(message = "Order items are required")
    @Valid
    private List<OrderItemRequest> items;
}
