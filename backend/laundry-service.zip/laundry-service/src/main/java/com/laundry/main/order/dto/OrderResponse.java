package com.laundry.main.order.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class OrderResponse {

    private Long orderId;
    private String orderNumber;
    private Long customerId;
    private String customerName;
    private LocalDate pickupDate;
    private LocalDate deliveryDate;
    private String status;
    private BigDecimal totalAmount;
    private List<OrderItemResponse> items;
}
